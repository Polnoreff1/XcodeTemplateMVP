//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//
//

import UIKit

protocol I___VARIABLE_sceneName___Presenter {
  func viewDidLoad()
  var viewModel: ___VARIABLE_sceneName___ViewModel? { get }
}

final class ___VARIABLE_sceneName___Presenter: I___VARIABLE_sceneName___Presenter {
  
  /*
   // MARK: - Presenter
   Presenter - this class implements the interaction between the Model and the View and contains all the logic.
   Presenter can implement actions, class or service methods.
  */
  
  // Dependencies
  weak var view: I___VARIABLE_sceneName___ViewController?
  private let viewModelFactory: I___VARIABLE_sceneName___ViewModelFactory
  private let router: I___VARIABLE_sceneName___Router
  
  // MARK: - Initialization
  
  init(
    viewModelFactory: I___VARIABLE_sceneName___ViewModelFactory,
    router: I___VARIABLE_sceneName___Router,
  ) {
    self.viewModelFactory = viewModelFactory
    self.router = router
  }
  
  // MARK: - I___VARIABLE_sceneName___Presenter
  
  var viewModel: ___VARIABLE_sceneName___ViewModel?
  
  func viewDidLoad() {
    let createdViewModel = viewModelFactory.makeViewModel()
    viewModel = createdViewModel
    view?.setup(with: viewModel)
  }
}
