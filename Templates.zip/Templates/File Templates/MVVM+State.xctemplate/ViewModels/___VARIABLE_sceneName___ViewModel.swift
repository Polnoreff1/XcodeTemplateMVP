//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//
//

struct ___VARIABLE_sceneName___ViewModel {
}
