//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//
//

import UIKit

protocol I___VARIABLE_sceneName___ViewModelFactory {
  func makeViewModel() -> ___VARIABLE_sceneName___ViewModel
}

final class ___VARIABLE_sceneName___ViewModelFactory: I___VARIABLE_sceneName___ViewModelFactory {
  
  func makeViewModel() -> ___VARIABLE_sceneName___ViewModel {
    let viewModel: ___VARIABLE_sceneName___ViewModel = ___VARIABLE_sceneName___ViewModel()
    return viewModel
  }
}
