//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//
//

import UIKit

protocol I___VARIABLE_sceneName___Assembly {
  func assemble() -> UIViewController
}

final class ___VARIABLE_sceneName___Assembly: I___VARIABLE_sceneName___Assembly {
  
  // Dependencies
  private let viewModelFactory: I___VARIABLE_sceneName___ViewModelFactory
  // other services...
  
  // MARK: - Initialization
  
  init(viewModelFactory: I___VARIABLE_sceneName___ViewModelFactory = ___VARIABLE_sceneName___ViewModelFactory()) {
    self.viewModelFactory = viewModelFactory
  }
  
  // MARK: - I___VARIABLE_sceneName___Assembly
  
  func assemble() -> UIViewController {
    let router: ___VARIABLE_sceneName___Router = ___VARIABLE_sceneName___Router()
    let presenter: ___VARIABLE_sceneName___Presenter = ___VARIABLE_sceneName___Presenter(
      viewModelFactory: viewModelFactory,
      router: router
    )
    
    let viewController: ___VARIABLE_sceneName___ViewController = ___VARIABLE_sceneName___ViewController(presenter: presenter)
    presenter.view = viewController
    router.transitionHandler = viewController
    
    return viewController
  }
}
