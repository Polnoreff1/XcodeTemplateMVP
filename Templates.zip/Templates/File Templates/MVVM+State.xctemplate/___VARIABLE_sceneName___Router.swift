//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//
//

import UIKit

protocol I___VARIABLE_sceneName___Router {
  func showNextScreen()
}

final class ___VARIABLE_sceneName___Router: I___VARIABLE_sceneName___Router {
  
  weak var transitionHandler: UIViewController?
  
  /*
   // MARK: - Router
   Router - this class is used to implement the transition functionality and show other screens.
   Use an initializer for injection assembly other screens, and transitionHandler as the screen from which the next screen will be shown
   
   init(nextScreenAssembly: InextScreenAssembly) {
      self.nextScreenAssembly = nextScreenAssembly
   }
   */
  
  func showNextScreen() {
  }
}
