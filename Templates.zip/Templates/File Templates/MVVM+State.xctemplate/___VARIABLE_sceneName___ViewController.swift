//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//
//

import UIKit

protocol I___VARIABLE_sceneName___ViewController: AnyObject {
  func setup(with: ___VARIABLE_sceneName___ViewModel)
}

final class ___VARIABLE_sceneName___ViewController: UIViewController {
  
  // MARK: - IBOutlet
  
  // MARK: - Properties
  
  private let presenter: I___VARIABLE_sceneName___Presenter
  
  // MARK: - Lifecycle
  
  init(presenter: I___VARIABLE_sceneName___Presenter) {
    self.presenter = presenter
    
    super.init(nibName: nil, bundle: nil)
  }
  
  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    setupUI()
    presenter.viewDidLoad()
  }
  
  // MARK: - Private Methods
  
  private func setupUI() {
  }
  
  // MARK: - IBActions
  
}

// MARK: - Extensions

extension ___VARIABLE_sceneName___ViewController: I___VARIABLE_sceneName___ViewController {
  func setup(with viewModel: ___VARIABLE_sceneName___ViewModel) {
  }
}
